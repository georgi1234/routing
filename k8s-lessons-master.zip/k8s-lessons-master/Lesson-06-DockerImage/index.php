<?php
$ip_server = $_SERVER['SERVER_ADDR'];

echo "<h1>Hello From Kubernetes</h1><br>";
echo "Server IP Address is: $ip_server", "<br><p>";
echo "Made by <font color=blue>Denis Astahov";
?>
